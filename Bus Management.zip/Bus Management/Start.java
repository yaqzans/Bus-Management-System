import java.lang.*;

public class Start 
{
	public static void main(String[] args)
	{
		Login obj1 = new Login();
		//RegistrationWindow obj1 = new RegistrationWindow();
		//Main obj1 = new Main();
		//Passenger1 obj1 = new Passenger1();
		//Passenger2 obj1 = new Passenger2();
		//Passenger3 obj1 = new Passenger3();
		//Passenger4 obj1 = new Passenger4();
		//Ticket obj1 = new Ticket();
		obj1.setVisible(true);
	}
}